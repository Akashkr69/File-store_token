from bot import Bot

Bot().run()
